# 🤖 Hrudhi AI Agent - Compressed Installer

## Quick Start
1. **Windows**: Double-click `Start_Hrudhi.bat`
2. **Linux/Mac**: Run `./start_hrudhi.sh` or `python3 hrudhi_installer.py`
3. Click "Install Dependencies" on first run
4. Click "Launch Hrudhi" to start your AI assistant

## What is Hrudhi?
Hrudhi is your personal AI-powered note-taking companion that:
- 🧠 **Remembers everything** you tell it with smart search
- 🔍 **Finds notes by context** not just keywords
- 💡 **Learns from your notes** to get better over time
- 🎨 **Beautiful modern interface** with a cute robot companion
- 🔒 **100% private** - all data stays on your computer

## System Requirements
- **Python 3.8+** (Download from python.org)
- **Internet connection** (first run only, ~500MB download)
- **2GB free disk space** (for AI models)
- **Windows 10+, Linux, or macOS**

## File Sizes
- **This installer**: ~5-15MB (compressed)
- **After setup**: ~2GB (includes AI models)
- **Your notes**: Minimal (just text files)

## Features
- ✅ Smart contextual note search using AI
- ✅ Clean, modern interface with robot companion
- ✅ Automatic categorization and organization
- ✅ Learning AI that improves with use
- ✅ Offline operation after initial setup
- ✅ Cross-platform compatibility
- ✅ No cloud, no tracking, no ads

## Troubleshooting

**"Python not found"**
- Download Python from python.org
- Make sure "Add to PATH" is checked during installation

**"Installation failed"**
- Check internet connection
- Try running as administrator (Windows)
- Ensure antivirus isn't blocking the installation

**"Module not found"**
- Try: `python -m pip install --upgrade pip`
- Then rerun the installer

## Privacy & Security
- All notes stored locally in `~/Desktop/HrudhiNotes/`
- No data sent to external servers
- Open source code available for review
- AI models run entirely on your computer

## Support
- GitHub Issues: Report bugs and feature requests
- Documentation: Full user guide in repository
- Community: Join discussions and share tips

Enjoy your new AI companion! 🤖✨
