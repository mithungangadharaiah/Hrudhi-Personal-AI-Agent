#!/bin/bash
echo "🤖 Starting Hrudhi AI Agent Setup..."
python3 hrudhi_installer.py || {
    echo "❌ Failed to start installer. Make sure Python 3.8+ is installed."
    read -p "Press Enter to exit..."
}
