#!/usr/bin/env python3
"""
Hrudhi Compressed Installer
Downloads and installs dependencies, then runs the application
"""

import os
import sys
import subprocess
import tkinter as tk
from tkinter import messagebox, ttk
import threading
import json
import datetime
import tempfile
import zipfile
from pathlib import Path

class HrudhiCompressedInstaller:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Hrudhi AI Agent - Setup")
        self.root.geometry("500x400")
        self.root.resizable(False, False)
        
        # App data directory
        self.app_dir = Path.home() / "AppData" / "Local" / "Hrudhi"
        self.app_dir.mkdir(parents=True, exist_ok=True)
        
        self.setup_ui()
        self.check_installation()
    
    def setup_ui(self):
        # Header
        header_frame = tk.Frame(self.root, bg="#6366F1", height=80)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text="🤖 Hrudhi AI Agent", 
                              font=("Arial", 18, "bold"), fg="white", bg="#6366F1")
        title_label.pack(expand=True)
        
        subtitle_label = tk.Label(header_frame, text="Your Personal AI Note Assistant", 
                                 font=("Arial", 10), fg="#E0E7FF", bg="#6366F1")
        subtitle_label.pack()
        
        # Main content
        content_frame = tk.Frame(self.root, padx=40, pady=30)
        content_frame.pack(fill=tk.BOTH, expand=True)
        
        # Status
        self.status_label = tk.Label(content_frame, text="Checking installation...", 
                                   font=("Arial", 11))
        self.status_label.pack(pady=(0, 20))
        
        # Progress bar
        self.progress = ttk.Progressbar(content_frame, mode='indeterminate', 
                                      style="TProgressbar")
        self.progress.pack(pady=(0, 20), fill=tk.X)
        
        # Buttons frame
        button_frame = tk.Frame(content_frame)
        button_frame.pack(pady=10)
        
        # Install button
        self.install_btn = tk.Button(button_frame, text="📦 Install Dependencies", 
                                   command=self.start_installation, 
                                   font=("Arial", 10, "bold"),
                                   bg="#10B981", fg="white", 
                                   padx=20, pady=8,
                                   state=tk.DISABLED)
        self.install_btn.pack(pady=5)
        
        # Launch button
        self.launch_btn = tk.Button(button_frame, text="🚀 Launch Hrudhi", 
                                  command=self.launch_hrudhi,
                                  font=("Arial", 10, "bold"),
                                  bg="#6366F1", fg="white",
                                  padx=20, pady=8,
                                  state=tk.DISABLED)
        self.launch_btn.pack(pady=5)
        
        # Info label
        info_label = tk.Label(content_frame, 
                             text="First run requires internet connection\nfor AI model downloads (~500MB)",
                             font=("Arial", 9), fg="#6B7280", justify=tk.CENTER)
        info_label.pack(pady=(20, 0))
    
    def check_installation(self):
        config_file = self.app_dir / "config.json"
        if config_file.exists():
            self.status_label.config(text="✅ Hrudhi is ready to use!", fg="#10B981")
            self.launch_btn.config(state=tk.NORMAL)
        else:
            self.status_label.config(text="⚙️ First time setup required", fg="#F59E0B")
            self.install_btn.config(state=tk.NORMAL)
    
    def start_installation(self):
        self.install_btn.config(state=tk.DISABLED)
        self.progress.start()
        
        # Run installation in separate thread
        thread = threading.Thread(target=self.install_dependencies)
        thread.daemon = True
        thread.start()
    
    def install_dependencies(self):
        try:
            # Update status for each step
            steps = [
                ("🔍 Checking Python environment", None),
                ("📦 Installing sentence-transformers", "sentence-transformers"),
                ("🧮 Installing scikit-learn", "scikit-learn"),
                ("🔢 Installing numpy", "numpy"),
                ("🔥 Installing torch", "torch"),
                ("🤖 Installing transformers", "transformers"),
                ("✨ Finalizing setup", None)
            ]
            
            for i, (message, package) in enumerate(steps):
                self.root.after(0, lambda m=message: 
                    self.status_label.config(text=m))
                
                if package:
                    subprocess.run([sys.executable, "-m", "pip", "install", package], 
                                 check=True, capture_output=True)
            
            # Create config file
            config = {
                "installed": True,
                "version": "1.0.0",
                "install_date": str(datetime.datetime.now()),
                "compressed_installer": True
            }
            
            with open(self.app_dir / "config.json", "w") as f:
                json.dump(config, f, indent=2)
            
            # Update UI on main thread
            self.root.after(0, self.installation_complete)
            
        except Exception as e:
            self.root.after(0, lambda: self.installation_failed(str(e)))
    
    def installation_complete(self):
        self.progress.stop()
        self.status_label.config(text="🎉 Installation completed successfully!", fg="#10B981")
        self.launch_btn.config(state=tk.NORMAL)
        messagebox.showinfo("Success", "Hrudhi is ready to use!\n\nYour AI companion is now ready to help you with note-taking!")
    
    def installation_failed(self, error):
        self.progress.stop()
        self.status_label.config(text="❌ Installation failed", fg="#EF4444")
        self.install_btn.config(state=tk.NORMAL)
        messagebox.showerror("Error", f"Installation failed: {error}\n\nPlease check your internet connection and try again.")
    
    def launch_hrudhi(self):
        try:
            # Import and run main Hrudhi application
            self.root.destroy()
            import hrudhi_main
            hrudhi_main.run()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to launch Hrudhi: {e}")

if __name__ == "__main__":
    app = HrudhiCompressedInstaller()
    app.root.mainloop()
