
import sys
import os

# Add current directory to path
sys.path.insert(0, os.path.dirname(__file__))

from hrudhi.hrudhi import HrudhiApp, initialize
import tkinter as tk

def run():
    """Run the main Hrudhi application"""
    try:
        print("🧠 Initializing AI models...")
        initialize()
        root = tk.Tk()
        app = HrudhiApp(root)
        root.mainloop()
    except Exception as e:
        import traceback
        print(f"Error launching Hrudhi: {e}")
        print(traceback.format_exc())
        input("Press Enter to exit...")

if __name__ == "__main__":
    run()
