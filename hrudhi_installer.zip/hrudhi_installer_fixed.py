#!/usr/bin/env python3
"""
Hrudhi Fixed Installer
Fixed version with better error handling and button responsiveness
"""

import os
import sys
import subprocess
import tkinter as tk
from tkinter import messagebox, ttk
import threading
import json
import datetime
from pathlib import Path

class HrudhiFixedInstaller:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Hrudhi AI Agent - Setup")
        self.root.geometry("500x450")
        self.root.resizable(False, False)
        
        # App data directory
        self.app_dir = Path.home() / "AppData" / "Local" / "Hrudhi"
        self.app_dir.mkdir(parents=True, exist_ok=True)
        
        self.installing = False
        self.setup_ui()
        
        # Check installation after UI is set up
        self.root.after(100, self.check_installation)
    
    def setup_ui(self):
        # Header
        header_frame = tk.Frame(self.root, bg="#6366F1", height=80)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text="🤖 Hrudhi AI Agent", 
                              font=("Arial", 18, "bold"), fg="white", bg="#6366F1")
        title_label.pack(expand=True)
        
        subtitle_label = tk.Label(header_frame, text="Your Personal AI Note Assistant", 
                                 font=("Arial", 10), fg="#E0E7FF", bg="#6366F1")
        subtitle_label.pack()
        
        # Main content
        content_frame = tk.Frame(self.root, padx=40, pady=30)
        content_frame.pack(fill=tk.BOTH, expand=True)
        
        # Status
        self.status_label = tk.Label(content_frame, text="Initializing...", 
                                   font=("Arial", 11), wraplength=400)
        self.status_label.pack(pady=(0, 20))
        
        # Progress bar
        self.progress = ttk.Progressbar(content_frame, mode='indeterminate')
        self.progress.pack(pady=(0, 20), fill=tk.X)
        
        # Buttons frame
        button_frame = tk.Frame(content_frame)
        button_frame.pack(pady=10)
        
        # Install button
        self.install_btn = tk.Button(button_frame, text="📦 Install Dependencies", 
                                   command=self.on_install_click, 
                                   font=("Arial", 10, "bold"),
                                   bg="#10B981", fg="white", 
                                   padx=20, pady=8,
                                   cursor="hand2")
        self.install_btn.pack(pady=5)
        
        # Launch button
        self.launch_btn = tk.Button(button_frame, text="🚀 Launch Hrudhi", 
                                  command=self.on_launch_click,
                                  font=("Arial", 10, "bold"),
                                  bg="#6366F1", fg="white",
                                  padx=20, pady=8,
                                  cursor="hand2")
        self.launch_btn.pack(pady=5)
        
        # Debug button (for troubleshooting)
        self.debug_btn = tk.Button(button_frame, text="🔧 Debug Info", 
                                 command=self.show_debug_info,
                                 font=("Arial", 9),
                                 bg="#6B7280", fg="white",
                                 padx=15, pady=5,
                                 cursor="hand2")
        self.debug_btn.pack(pady=5)
        
        # Info label
        info_label = tk.Label(content_frame, 
                             text="First run requires internet connection\\nfor AI model downloads (~500MB)\\n\\nIf button doesn't work, try running as Administrator",
                             font=("Arial", 9), fg="#6B7280", justify=tk.CENTER)
        info_label.pack(pady=(20, 0))
        
        # Log text area (initially hidden)
        self.log_frame = tk.Frame(content_frame)
        self.log_text = tk.Text(self.log_frame, height=8, width=50, font=("Consolas", 8))
        scrollbar = tk.Scrollbar(self.log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scrollbar.set)
        
        self.log_text.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
    
    def log(self, message):
        """Add message to log and print to console"""
        print(f"[INSTALLER] {message}")
        try:
            self.log_text.insert("end", f"{message}\\n")
            self.log_text.see("end")
            self.root.update_idletasks()
        except:
            pass
    
    def show_debug_info(self):
        """Show debug information and logs"""
        if self.log_frame.winfo_viewable():
            self.log_frame.pack_forget()
            self.debug_btn.config(text="🔧 Debug Info")
            self.root.geometry("500x450")
        else:
            self.log_frame.pack(fill="both", expand=True, pady=(10, 0))
            self.debug_btn.config(text="🔧 Hide Debug")
            self.root.geometry("500x650")
            
            # Add system info
            self.log("=== System Info ===")
            self.log(f"Python: {sys.version}")
            self.log(f"Platform: {sys.platform}")
            self.log(f"App Dir: {self.app_dir}")
            self.log(f"Current Dir: {os.getcwd()}")
            self.log("==================")
    
    def check_installation(self):
        self.log("Checking installation status...")
        config_file = self.app_dir / "config.json"
        
        try:
            if config_file.exists():
                with open(config_file, 'r') as f:
                    config = json.load(f)
                
                self.log("Found existing installation config")
                self.status_label.config(text="✅ Hrudhi is ready to use!", fg="#10B981")
                self.install_btn.config(state=tk.DISABLED, text="✅ Already Installed")
                self.launch_btn.config(state=tk.NORMAL)
            else:
                self.log("No installation config found - first time setup required")
                self.status_label.config(text="⚙️ First time setup required", fg="#F59E0B")
                self.install_btn.config(state=tk.NORMAL)
                self.launch_btn.config(state=tk.DISABLED)
        except Exception as e:
            self.log(f"Error checking installation: {e}")
            self.status_label.config(text="⚙️ Setup required (config error)", fg="#F59E0B")
            self.install_btn.config(state=tk.NORMAL)
            self.launch_btn.config(state=tk.DISABLED)
    
    def on_install_click(self):
        """Handle install button click"""
        if self.installing:
            self.log("Installation already in progress...")
            return
        
        self.log("Install button clicked!")
        
        # Show confirmation dialog
        result = messagebox.askyesno(
            "Install Dependencies",
            "This will install required Python packages for AI functionality.\\n\\n" +
            "Requirements:\\n" +
            "• Internet connection\\n" +
            "• ~500MB download\\n" +
            "• 2-5 minutes\\n\\n" +
            "Continue with installation?"
        )
        
        if result:
            self.start_installation()
    
    def start_installation(self):
        """Start the installation process"""
        self.installing = True
        self.install_btn.config(state=tk.DISABLED, text="Installing...")
        self.launch_btn.config(state=tk.DISABLED)
        self.progress.start()
        
        self.log("Starting installation process...")
        
        # Run installation in separate thread
        thread = threading.Thread(target=self.install_dependencies, daemon=True)
        thread.start()
    
    def install_dependencies(self):
        """Install all required dependencies"""
        packages = [
            ("sentence-transformers", "🧠 AI embeddings"),
            ("transformers", "🤖 Language models"),
            ("torch", "🔥 PyTorch framework"),
            ("sumy", "📝 Text summarization"),
            ("nltk", "🔤 Language processing"),
            ("beautifulsoup4", "🌐 Web scraping"),
            ("requests", "📡 HTTP requests"),
            ("scikit-learn", "🧮 Machine learning"),
            ("numpy", "🔢 Numerical computing")
        ]
        
        try:
            total_packages = len(packages)
            
            for i, (package, description) in enumerate(packages, 1):
                # Update status on main thread
                status_msg = f"{description} ({i}/{total_packages})"
                self.root.after(0, lambda msg=status_msg: 
                    self.status_label.config(text=msg))
                
                self.log(f"Installing {package}...")
                
                # Install package
                result = subprocess.run([
                    sys.executable, "-m", "pip", "install", package, "--user", "--quiet"
                ], capture_output=True, text=True, timeout=300)
                
                if result.returncode != 0:
                    self.log(f"Warning: {package} installation had issues: {result.stderr}")
                    # Try without --user flag
                    result = subprocess.run([
                        sys.executable, "-m", "pip", "install", package, "--quiet"
                    ], capture_output=True, text=True, timeout=300)
                    
                    if result.returncode != 0:
                        raise Exception(f"Failed to install {package}: {result.stderr}")
                
                self.log(f"✅ {package} installed successfully")
            
            # Create config file
            config = {
                "installed": True,
                "version": "1.0.0",
                "install_date": str(datetime.datetime.now()),
                "installer_type": "compressed",
                "packages_installed": [pkg[0] for pkg in packages]
            }
            
            config_file = self.app_dir / "config.json"
            with open(config_file, "w") as f:
                json.dump(config, f, indent=2)
            
            self.log("Configuration saved successfully")
            
            # Update UI on main thread
            self.root.after(0, self.installation_complete)
            
        except subprocess.TimeoutExpired:
            self.log("Installation timed out - this might indicate network issues")
            self.root.after(0, lambda: self.installation_failed("Installation timed out. Please check your internet connection."))
        except Exception as e:
            self.log(f"Installation failed with error: {e}")
            self.root.after(0, lambda: self.installation_failed(str(e)))
    
    def installation_complete(self):
        """Handle successful installation"""
        self.installing = False
        self.progress.stop()
        self.status_label.config(text="🎉 Installation completed successfully!", fg="#10B981")
        self.install_btn.config(text="✅ Installed", state=tk.DISABLED)
        self.launch_btn.config(state=tk.NORMAL)
        
        self.log("🎉 Installation completed successfully!")
        
        messagebox.showinfo(
            "Success", 
            "Hrudhi is ready to use!\\n\\n" +
            "Your AI companion is now ready to help you with:\\n" +
            "• Intelligent note-taking\\n" +
            "• Smart conversations\\n" +
            "• Text summarization\\n" +
            "• Web content learning"
        )
    
    def installation_failed(self, error):
        """Handle failed installation"""
        self.installing = False
        self.progress.stop()
        self.status_label.config(text="❌ Installation failed", fg="#EF4444")
        self.install_btn.config(state=tk.NORMAL, text="📦 Retry Installation")
        
        self.log(f"❌ Installation failed: {error}")
        
        messagebox.showerror(
            "Installation Failed", 
            f"Installation failed: {error}\\n\\n" +
            "Troubleshooting tips:\\n" +
            "• Check internet connection\\n" +
            "• Run as Administrator\\n" +
            "• Disable antivirus temporarily\\n" +
            "• Click 'Debug Info' for more details"
        )
    
    def on_launch_click(self):
        """Handle launch button click"""
        self.log("Launching Hrudhi...")
        
        try:
            # Try to launch main application
            main_script = Path("hrudhi_main.py")
            if main_script.exists():
                subprocess.Popen([sys.executable, str(main_script)])
                self.root.destroy()
            else:
                # Fallback - try to run from hrudhi directory
                hrudhi_script = Path("hrudhi") / "hrudhi.py"
                if hrudhi_script.exists():
                    subprocess.Popen([sys.executable, str(hrudhi_script)])
                    self.root.destroy()
                else:
                    raise FileNotFoundError("Could not find Hrudhi main application")
                    
        except Exception as e:
            self.log(f"Launch failed: {e}")
            messagebox.showerror("Launch Error", f"Failed to launch Hrudhi: {e}")

def main():
    try:
        app = HrudhiFixedInstaller()
        app.root.mainloop()
    except Exception as e:
        print(f"Fatal error: {e}")
        messagebox.showerror("Fatal Error", f"Installer crashed: {e}")

if __name__ == "__main__":
    main()